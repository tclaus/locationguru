
$(function () {
  $("#auto_address_navbar").geocomplete();
});
