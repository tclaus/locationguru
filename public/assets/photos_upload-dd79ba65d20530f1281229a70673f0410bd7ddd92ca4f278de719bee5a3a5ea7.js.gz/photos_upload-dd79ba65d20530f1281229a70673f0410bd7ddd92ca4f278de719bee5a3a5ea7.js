
  $('#filelist').on('change', function() {
    $('form').submit();
  });
