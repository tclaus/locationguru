$('#profile').on('change', function() {
  $('form').submit();
});
