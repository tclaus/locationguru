
  $(function() {
    $("#auto_location").geocomplete();
  });
